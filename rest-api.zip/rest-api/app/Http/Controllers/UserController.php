<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->get('search', '');
        $page = $request->get('page', 1);
        $sortBy = $request->get('sortBy', 'created_at');

        $users = User::withCount('orders')
        ->when($search, fn($query) => $query->where('name', 'like', "%{$search}%")
            ->orWhere('email', 'like', "%{$search}%"))
        ->orderBy($sortBy)
        ->paginate(10, ['*'], 'page', $page);

        return response()->json([
            'page' => $users->currentPage(),
            'users' => $users->items(),
        ]);
    }

    public function store(Request $request)
    {
        
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:8',
            'name' => 'required|string|min:3|max:50',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'errors' => $validator->errors(),
            ], 422);
        }

        $user = User::create([
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'name' => $request->name,
        ]);

        Mail::to($user->email)->send(new \App\Mail\UserCreated($user));
        Mail::to('example@example.com')->send(new \App\Mail\AdminNotification($user));

        return response()->json([
            'id' => $user->id,
            'email' => $user->email,
            'name' => $user->name,
            'created_at' => $user->created_at->toISOString(),
        ]);
    }
}
